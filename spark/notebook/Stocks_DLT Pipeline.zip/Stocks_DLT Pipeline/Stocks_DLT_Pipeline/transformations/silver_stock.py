import dlt

from pyspark.sql.functions import col, when, to_timestamp



@dlt.table(
    name="stocks_silver_df",
    comment="Cleaned and deduplicated stock data"
)
def stocks_silver():
    bronze_stocks_df = dlt.read("stocks_bronze_df")
    bronze_meta_data_df = dlt.read("stocks_bronze_meta_df")
    silver_stocks_df = bronze_stocks_df.withColumn("date", to_timestamp(col("date"), format="yyyy-MM-dd"))
    silver_stocks_df = silver_stocks_df.join(bronze_meta_data_df, on="symbol", how="inner")
    return silver_stocks_df