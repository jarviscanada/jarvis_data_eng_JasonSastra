import dlt
import requests
from pyspark.sql import Row
from pyspark.sql.functions import col
from pyspark.sql import SparkSession

@dlt.table(
    name="stocks_bronze_meta_df",  
    comment="Raw meta data from Alpha Vantage"
)
def stocks_bronze():
    symbols = ["GOOGL", "AAPL", "MSFT", "TSLA"]

    all_data = []

    for symbol in symbols:
        querystring = {
            "function": "OVERVIEW",
            "symbol": symbol,        
            "datatype": "json",
            "outputsize": "compact"
        }

        headers = {
            "X-RapidAPI-Host": "alpha-vantage.p.rapidapi.com",
            "X-RapidAPI-Key": "92d92f3032msh05701a5e9918f16p1555edjsnca05a8131ba6"
        }

        response = requests.get("https://alpha-vantage.p.rapidapi.com/query", headers=headers, params=querystring)
        print(response.json())
        data = response.json()
        all_data.append(Row(
            symbol=symbol,
            name=data.get("Name"),
            sector=data.get("Sector"),
            industry=data.get("Industry"),
            exchange=data.get("Exchange"),
            country=data.get("Country")
        ))

    meta_data_df = spark.createDataFrame(all_data)
    display(meta_data_df)
    return meta_data_df