import dlt
import requests
from pyspark.sql import Row, SparkSession
from pyspark.sql.functions import col

@dlt.table(
    name="stocks_bronze_df",  
    comment="Raw daily stock prices from Alpha Vantage"
)
def stocks_bronze():

    symbols = ["GOOGL", "AAPL", "MSFT", "TSLA"]
    all_data = []

    for symbol in symbols:
        querystring = {
            "function": "TIME_SERIES_DAILY",
            "symbol": symbol,
            "datatype": "json",
            "outputsize": "compact"
        }

        headers = {
            "X-RapidAPI-Host": "alpha-vantage.p.rapidapi.com",
            "X-RapidAPI-Key": "92d92f3032msh05701a5e9918f16p1555edjsnca05a8131ba6"
        }

        response = requests.get("https://alpha-vantage.p.rapidapi.com/query", headers=headers, params=querystring)
        data = response.json()
        time_series = data.get("Time Series (Daily)", {})

        for date, daily_data in time_series.items():
            all_data.append(Row(
                symbol=symbol,
                date=date,
                open=float(daily_data["1. open"]),
                high=float(daily_data["2. high"]),
                low=float(daily_data["3. low"]),
                close=float(daily_data["4. close"]),
                volume=int(daily_data["5. volume"])
            ))

    stocks_df = spark.createDataFrame(all_data)

    display(stocks_df)

    return stocks_df