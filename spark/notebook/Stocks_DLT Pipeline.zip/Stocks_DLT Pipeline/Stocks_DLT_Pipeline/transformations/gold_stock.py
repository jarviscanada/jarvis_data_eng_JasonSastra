import dlt

from pyspark.sql.functions import col, when, to_timestamp, col, avg, max, min, date_add



@dlt.table(
    name="stocks_gold_df",
    comment="Cleaned and deduplicated stock data"
)
def stocks_gold():
    silver_stocks_df = dlt.read("stocks_silver_df")
    silver_stocks_df = (
        silver_stocks_df
        .withColumn("daily_return", col("close") - col("open"))
        .withColumn("price_change", col("close") / col("open"))
    )

    day_comparison_df = (silver_stocks_df.alias("cur_stocks")
        .join(silver_stocks_df.alias("prev_stocks"), (col("cur_stocks.date") == date_add(col("prev_stocks.date"), 1)) 
        & (col("cur_stocks.symbol") == col("prev_stocks.symbol")))
        .withColumn("open_change", col("cur_stocks.open") - col("prev_stocks.open"))
        .withColumn("close_change", col("cur_stocks.close") - col("prev_stocks.close"))
        .withColumn("open_change_percent", col("cur_stocks.open") / col("prev_stocks.open"))
        .withColumn("close_change_percent", col("cur_stocks.close") / col("prev_stocks.close"))
        .select("cur_stocks.symbol", "cur_stocks.date", "cur_stocks.open", "cur_stocks.high", "cur_stocks.low", "cur_stocks.close", "cur_stocks.volume", "cur_stocks.daily_return", "cur_stocks.price_change", "open_change", "close_change", "open_change_percent", "close_change_percent", "cur_stocks.exchange", "cur_stocks.country", "cur_stocks.industry")
    )
    return day_comparison_df